#!/bin/sh

exec ./tst-pam_authfail tst-pam_substack5
